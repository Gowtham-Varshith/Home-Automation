export const SET_NEW_USER = "SET_NEW_USER ";
export const SET_PICTURE_URL = "SET_PICTURE_URL";
export const SET_USER_KEY = "SET_USER_KEY";